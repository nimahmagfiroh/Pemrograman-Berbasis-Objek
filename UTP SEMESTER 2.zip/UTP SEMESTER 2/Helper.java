package com.company;

public class Helper {
    // Helper to initialize
    static void initialize(){
        // Initilaize admin
        Main.admins[0] = new Admin("Joko", "ini_password_joko");
        Main.admins[1] = new Admin("Dengklek", "ini_password_dengklek");

        // Initialize Layanan
        // Masukkan daftar-daftar layanan bersesuaian dengan dokumen
        Layanan layanan1 = new Layanan("Ganti Oli", 500000);
        Layanan layanan2 = new Layanan("Operasi Mobil", 2000000, "Mobil Anda mengalami mogok mendadak? Tidak bisa dinyalakan? Tenang, kami\n" +
                "memiliki tenaga ahli untuk mengoperasi mobil Anda. Cukup dengan Rp. 2.000.000,\n" +
                "mobil Anda akan sehat seperti sedia kala");
        Layanan layanan3 = new Layanan("Ketok Magic", 3000000, "Ketok Magic adalah layanan sulap untuk menghilangkan penyok pada body mobil.\n" +
                "Apapun masalahnya, BIM SALABIM, bakal waras! Rogoh kantong Anda\n" +
                "sebanyak Rp. 3.000.000 dan dapatkan mobil baru seperti sedia kala.");
        Layanan layanan4 = new Layanan("Mobil Racing", 5000000, "Bagi kalian jiwa muda yang ingin balapan, kami bisa modifikasi mobil kalian\n" +
                "dengan tambahan NOS, serta body standar untuk balapan seharga Rp. 5.000.000\n" +
                "saja dan mobil Anda siap untuk menembus angin.");
        Layanan layanan5 = new Layanan("Modifikasi Mobil Elektrik", 5500000, "Modifikasi ini adalah modifikasi baru pada layanan bengkel kami, dimana Anda\n" +
                "dapat mengubah mesin yang bertenagakan fosil menjadi bertenaga listrik dengan\n" +
                "harga Rp. 5.500.000.");
    }

    // Helper function to authentication
    // Fungsi yang digunakan untuk "melakukan loop" pada iterasi admins
    static boolean authentication(String username, String password) {
        // Rubah Kode di sini
        return true;
    }

    // Helper to format price to rupiah
    static String getFormattedPrice(int price){
        return String.format("Rp. %,d", price);
    }
}
